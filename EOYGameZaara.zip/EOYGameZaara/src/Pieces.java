
public class Pieces {

	private String image1;
	private String image2;
	private String image3;
	private String image4;
	private String image5;
	private String image6;
	private String image7;
	private String image8;
	private String image9;
	
	public Pieces() {
	image1= "butterfly1.png";
	image2= "butterfly2.png";
	image3= "butterfly3.png";
	image4= "butterfly4.png";
	image5= "butterfly5.png";
	image6= "butterfly6.png";
	image7= "butterfly7.png";
	image8= "butterfly8.png";
	image9= "butterfly9.png";
	
	
	}
	public String getImage1(){
	return image1;
	}
	public String getImage2(){
	return image2;
	}
	public String getImage3() {
		return image3;
	}
	public String getImage4() {
		return image4;
	}

	public String getImage5(){
	return image5;
	}
	public String getImage6(){
	return image6;
	}
	
	public String getImage7() {
		return image7;
	}
	public String getImage8() {
		return image8;
	}
	
	public String getImage9() {
		return image9;
	}
	
	}


